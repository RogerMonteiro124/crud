<?php
    require '../banco.php';
    
    if(!empty($_POST))
    {
        //Acompanha os erros de validação
        $nomeErro = null;
        $dataNascimentoErro = null;        
        $nome_aluno= $_POST['nome'];
        $data_nascimento= $_POST['data_nascimento'];        
        $select_curso = $_POST['select_curso'];
        $cep= $_POST['cep'];
        $logradouro =$_POST['rua'];
        $numero= $_POST['numero'];
        $bairro= $_POST['bairro'];
        $cidade= $_POST['cidade'];
        $estado= $_POST['uf'];

        //Validaçao dos campos:
        $validacao = true;
        if(empty($nome_aluno))
        {
            $nomeErro = 'Por favor digite o seu nome!';
            $validacao = false;
        }        
        $dada=date('d-m-y');
        
        
        //Inserindo no Banco:
        if($validacao)
        {
            $pdo = Banco::conectar();
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $sql = "INSERT INTO aluno (nome_aluno, data_nascimento, cep, logradouro, numero, bairro, cidade, estado, data_criacao, id_curso)VALUES(?,?,?,?,?,?,?,?,?,?)";
            $q = $pdo->prepare($sql);
            $q->execute(array($nome_aluno,$data_nascimento,$cep,$logradouro,$numero,$bairro,$cidade,$estado,$dada,$select_curso));            
            Banco::desconectar();
            echo'<script language= "JavaScript">
                    location.href="index.php"
                </script>'
            ;
        }
    }
?>