<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="utf-8">
        <link href="../css/bootstrap.min.css" rel="stylesheet">
        <script src="../js/bootstrap.min.js"></script>
    </head>
    
    <body>
        <div class="jumbotron">
        <div class="container">
            <div class="row">
                <h1> CRUD em PHP </h1>
            </div>
            </br>
            <div class="row">
                <p>
                    <a href="create.php" class="btn btn-success">Adicionar</a>
                
                    <a href="create.php" class="btn btn-primary">GERAR PDF</a>
                </p>
                <table class="table table-striped table-bordered">
                    <thead>
                        <tr>                                       
                            <th>Nome</th>
                            <th>Data Nascimento</th>
                            <th>cep</th>
                            <th>logradouro</th>
                            <th>numero</th>
                            <th>bairro</th>
                            <th>cidade</th>
                            <th>estado</th>
                            <th>id_curso</th>                          
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        include '../banco.php';
                        $pdo = Banco::conectar();
                        $sql = 'SELECT * FROM aluno';
                        foreach($pdo->query($sql)as $row)
                        {                
                            echo '<tr>';                            
                            echo '<td>'. $row['nome_aluno'] . '</td>';
                            echo '<td>'. $row['data_nascimento'] . '</td>';
                            echo '<td>'. $row['cep'] . '</td>';
                            echo '<td>'. $row['logradouro'] . '</td>';    

                            echo '<td>'. $row['numero'] . '</td>';
                            echo '<td>'. $row['bairro'] . '</td>';
                            echo '<td>'. $row['cidade'] . '</td>';
                            echo '<td>'. $row['estado'] . '</td>';
                            echo '<td>'. $row['id_curso'] . '</td>';


                            echo '<td width=250>';
                            echo '<a class="btn btn-primary" href="read.php?id_aluno='.$row['id_aluno'].'">Listar</a>';
                            echo ' ';
                            echo '<a class="btn btn-warning" href="update.php?id_aluno='.$row['id_aluno'].'">Atualizar</a>';
                            echo ' ';
                            echo '<a class="btn btn-danger" href="delete.php?id_aluno='.$row['id_aluno'].'">Excluir</a>';
                            echo '</td>';
                            echo '<tr>';
                        }
                        Banco::desconectar();
                        ?>
                    </tbody>                   
                </table>               
            </div>
        </div>
        </div>
    </body>
</html>
