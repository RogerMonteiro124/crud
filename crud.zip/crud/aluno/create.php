<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <link href="../css/bootstrap.min.css" rel="stylesheet">
        <script src="../js/bootstrap.min.js"></script>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

    <!-- Adicionando Javascript -->
    <script type="text/javascript" >
    
    function limpa_formulário_cep() {
            //Limpa valores do formulário de cep.
            document.getElementById('rua').value=("");
            document.getElementById('bairro').value=("");
            document.getElementById('cidade').value=("");
            document.getElementById('uf').value=("");    }

    function meu_callback(conteudo) {
        if (!("erro" in conteudo)) {
            //Atualiza os campos com os valores.
            document.getElementById('rua').value=(conteudo.logradouro);
            document.getElementById('bairro').value=(conteudo.bairro);
            document.getElementById('cidade').value=(conteudo.localidade);
            document.getElementById('uf').value=(conteudo.uf);
        } //end if.
        else {
            //CEP não Encontrado.
            limpa_formulário_cep();
            alert("CEP não encontrado.");
        }
    }
        
    function pesquisacep(valor) {

        //Nova variável "cep" somente com dígitos.
        var cep = valor.replace(/\D/g, '');

        //Verifica se campo cep possui valor informado.
        if (cep != "") {

            //Expressão regular para validar o CEP.
            var validacep = /^[0-9]{8}$/;

            //Valida o formato do CEP.
            if(validacep.test(cep)) {

                //Preenche os campos com "..." enquanto consulta webservice.
                document.getElementById('rua').value="...";
                document.getElementById('bairro').value="...";
                document.getElementById('cidade').value="...";
                document.getElementById('uf').value="...";

                //Cria um elemento javascript.
                var script = document.createElement('script');

                //Sincroniza com o callback.
                script.src = '//viacep.com.br/ws/'+ cep + '/json/?callback=meu_callback';

                //Insere script no documento e carrega o conteúdo.
                document.body.appendChild(script);

            } //end if.
            else {
                //cep é inválido.
                limpa_formulário_cep();
                alert("Formato de CEP inválido.");
            }
        } //end if.
        else {
            //cep sem valor, limpa formulário.
            limpa_formulário_cep();
        }
    };

    </script>
    </head>
    
    <body>
        <div class="container">
            <div clas="span10 offset1">
                <div class="row">
                    <h3 class="well"> Adicionar Aluno </h3>
                    <form method="Post" action="create_aluno.php">
                        
                        <div class="control-group <?php echo !empty($nomeErro)?'error ' : '';?>">
                            <label class="control-label">Nome</label>
                            <div class="controls">
                                <input size= "50" name="nome" type="text" placeholder="Nome" required="" value="<?php echo !empty($nome)?$nome: '';?>">
                                <?php if(!empty($nomeErro)): ?>
                                    <span class="help-inline"><?php echo $nomeErro;?></span>
                                <?php endif;?>
                            </div>
                        </div>

                        <div class="control-group <?php echo !empty($nomeErro)?'error ' : '';?>">
                            <label class="control-label">Data Nascimento</label>
                            <div class="controls">
                                <input size= "50" name="data_nascimento" type="date" placeholder="Data Nascimento" required="" value="<?php echo !empty($data_nascimento)?$data_nascimento: '';?>">
                                <?php if(!empty($dataNascimentoErro)): ?>
                                    <span class="help-inline"><?php echo $dataNascimentoErro;?></span>
                                <?php endif;?>
                            </div>
                        </div>

                        <label>Cep:</br>
                        <input name="cep" type="text" id="cep" value="" size="10" maxlength="9"
                               onblur="pesquisacep(this.value);" /></label><br />
                        <label>Rua:</br>
                        <input name="rua" type="text" id="rua" size="50" /></label><br />
                        <div class="control-group <?php echo !empty($nomeErro)?'error ' : '';?>">
                            <label class="control-label">Numero</label>
                            <div class="controls">
                                <input size= "50" name="numero" type="text" placeholder="numero" required="" value="<?php echo !empty($nome)?$nome: '';?>">
                                <?php //if(!empty($numeroErro)): ?>
                                    <span class="help-inline"><?php //echo $numeroErro;?></span>
                                <?php //endif;?>
                            </div>
                        </div></br>
                        <label>Bairro:</br>
                        <input name="bairro" type="text" id="bairro" size="50" /></label><br />
                        <label>Cidade:</br>
                        <input name="cidade" type="text" id="cidade" size="50" /></label><br />
                        <label>Estado:
                        <input name="uf" type="text" id="uf" size="10" /></label><br />                                               
                        <div class="control-group <?php echo !empty($nomeErro)?'error ' : '';?>">
                            <label class="control-label">Curso</label>
                            <div class="controls">

                        <?php
                            $con = new mysqli("localhost", "root", "","flex" ) or die (mysql_error());
                            $query = $con->query("SELECT * FROM curso");
                            ?>
                            <select name="select_curso">
                                <?php while($reg = $query->fetch_array()) { ?>
                                <option value="<?=$reg["id_curso"]?>"> <?=$reg["nome_curso"]?> </option>
                                <?php }?>
                            </select>    

                        <div class="form-actions">
                            <br/>                
                            <button type="submit" class="btn btn-success">Adicionar</button>
                            <a href="index.php" type="btn" class="btn btn-default">Voltar</a>
                        
                        </div>
                    </form>
                </div>
        </div>
    </body>
</html>
